# setup.R

install.packages('shiny') 